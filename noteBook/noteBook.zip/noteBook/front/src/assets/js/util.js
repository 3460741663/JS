const baseUrl = 'http://192.168.31.25:3000/'
export default {
  baseUrl
}